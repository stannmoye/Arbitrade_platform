# CoinKi Balanced Compact Core

Open `index.html` in a modern browser or upload it to your hosting document root.

This revision uses a compact, wide operating frame with separate, aligned zones: the animated ASIC scene on the left and a clearly spaced telemetry/work queue/reward/energy dock on the right. The modules remain inside the same outer border but no longer overlap or sit on top of the chip animation. On narrower screens, the layout stacks into a readable responsive arrangement.

All mining metrics and reward settlement are simulated visuals, not real mining or blockchain rewards.
